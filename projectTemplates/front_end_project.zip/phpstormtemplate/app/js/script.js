console.log("Script is active");
